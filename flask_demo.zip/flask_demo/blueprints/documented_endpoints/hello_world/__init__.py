# blueprints/documented_endpoints/hello_world/__init__.py
from http import HTTPStatus
from flask import request
import json
from flask_restplus import Namespace, Resource, fields

namespace = Namespace('banks', 'Banks endpoints')

bank_model = namespace.model('Bank', {
    'registered_name': fields.String(
        required=True,
        description='Registered name'
    ),
    'regafi_identifier': fields.String(
        required=True,
        description='Regafi identifier'
    ),
    'trading_name': fields.String(
        required=False,
        description='Trading name if any'
    )
})

bank_list_model = namespace.model('BankList', {
    'banks': fields.Nested(
        bank_model,
        description='List of banks',
        as_list=True
)})


@namespace.route('')
class HelloWorld(Resource):

    @namespace.response(500, 'Internal Server error')
    @namespace.marshal_list_with(bank_model)
    def get(self):
        '''Get bank list'''

        with open("bank_list.json", "r") as f:
            bank_example = json.load(f)

        return bank_example


    @namespace.response(400, "Entity with the given name already exists")
    @namespace.response(500, "Internal Server error")
    @namespace.expect(bank_list_model)
    @namespace.marshal_with(bank_list_model, code=HTTPStatus.CREATED)


    def post(self):
        '''Create bank(s)'''

        with open("bank_list.json", "r") as f:
            bank_example = json.load(f)

        list_of_bank = request.json
        for b in list_of_bank["banks"]:
            if b not in bank_example:
                bank_example.append(b)

        with open("bank_list.json", "w") as f:
            json.dump(bank_example, f, ensure_ascii=False, indent=True)

        return bank_example, 201


    @namespace.response(500, "Internal Server error")
    @namespace.expect(bank_list_model)
    @namespace.marshal_with(bank_list_model)
    def delete(self):
        '''Delete bank(s)'''

        with open("bank_list.json", "r") as f:
            bank_example = json.load(f)

        list_of_bank = request.json
        for b in list_of_bank["banks"]:
            bank_example.remove(b)
        
        with open("bank_list.json", "w") as f:
            json.dump(bank_example, f, ensure_ascii=False, indent=True)

        return bank_example, 201