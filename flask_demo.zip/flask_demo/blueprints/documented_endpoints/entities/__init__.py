# blueprints/documented_endpoints/entities/__init__.py
from flask import request
from flask_restplus import Namespace, Resource, fields
from http import HTTPStatus

namespace = Namespace('banks', 'Banks fake endpoints')

bank_model = namespace.model('Bank', {
    'registered_name': fields.String(
        required=True,
        description='Registered name'
    ),
    'regafi_identifier': fields.String(
        required=True,
        description='Regafi identifier'
    )
})

bank_list_model = namespace.model('BankList', {
    'banks': fields.Nested(
        bank_model,
        description='List of banks',
        as_list=True
    ),
    'total_records': fields.Integer(
        description='Total number of banks',
    ),
})

bank_example = {'registered_name':'Goldman Sachs', 'regafi_identifier': '123456789'}
# import json
# with open("bank_list.json", "r") as f:
#     entity_example = json.load(f)

@namespace.route('')
class entities(Resource):
    '''Get banks list and create new banks'''

    @namespace.response(500, 'Internal Server error')
    @namespace.marshal_list_with(bank_list_model)

    def get(self):
        '''List with all the banks'''
        bank_list = bank_example

        return {
            'entities': bank_list,
            #'total_records': len(entity_list)
        }

    @namespace.response(400, 'Entity with the given name already exists')
    @namespace.response(500, 'Internal Server error')
    @namespace.expect(bank_model)
    @namespace.marshal_with(bank_model, code=HTTPStatus.CREATED)

    def post(self):
        '''Create a new entity'''

        if request.json['name'] == 'Entity name':
            namespace.abort(400, 'Entity with the given name already exists')

        return bank_example, 201

@namespace.route('/<int:entity_id>')
class entity(Resource):
    '''Read, update and delete a specific entity'''

    @namespace.response(404, 'Entity not found')
    @namespace.response(500, 'Internal Server error')
    @namespace.marshal_with(bank_model)
    def get(self, entity_id):
        '''Get entity_example information'''

        return bank_example

    @namespace.response(400, 'Entity with the given name already exists')
    @namespace.response(404, 'Entity not found')
    @namespace.response(500, 'Internal Server error')
    @namespace.expect(bank_model, validate=True)
    @namespace.marshal_with(bank_model)
    def put(self, entity_id):
        '''Update entity information'''

        if request.json['name'] == 'Entity name':
            namespace.abort(400, 'Entity with the given name already exists')

        return bank_example

    @namespace.response(204, 'Request Success (No Content)')
    @namespace.response(404, 'Entity not found')
    @namespace.response(500, 'Internal Server error')
    def delete(self, entity_id):
        '''Delete a specific entity'''

        return '', 204