# blueprints/documented_endpoints/__init__.py
from flask import Blueprint
from flask_restplus import Api
from blueprints.documented_endpoints.hello_world import namespace as hello_world_ns
from blueprints.documented_endpoints.entities import namespace as entities_ns
from blueprints.documented_endpoints.jinja_template import namespace as jinja_template_ns


blueprint = Blueprint('documented_api', __name__, url_prefix='/documented_api')

api_extension = Api(
    blueprint,
    title='Bank List Update (BLU) API',
    version='1.0',
    description='Swagger to get, post or delete bank(s) from banks coming from regafi API.',
    doc='/doc'
)

api_extension.add_namespace(hello_world_ns)
# api_extension.add_namespace(entities_ns)
# api_extension.add_namespace(jinja_template_ns)